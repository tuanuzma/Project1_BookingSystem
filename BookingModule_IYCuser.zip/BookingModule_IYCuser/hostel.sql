-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2024 at 05:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `facilitybooking_details`
--

CREATE TABLE `facilitybooking_details` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `total_price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilitybooking_details`
--

INSERT INTO `facilitybooking_details` (`id`, `name`, `contact`, `email`, `total_price`) VALUES
(1, 'Uzma', '01124404469', 'noruzma20@gmail.com', 20050),
(2, 'Hannan', '0137595450', '13081k2@gmail.com', 500);

-- --------------------------------------------------------

--
-- Table structure for table `facility_booking`
--

CREATE TABLE `facility_booking` (
  `id` int(11) NOT NULL,
  `facilitybookingdetails_id` int(11) DEFAULT NULL,
  `facility_id` int(11) NOT NULL,
  `facility_type` varchar(100) NOT NULL,
  `pax_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facility_booking`
--

INSERT INTO `facility_booking` (`id`, `facilitybookingdetails_id`, `facility_id`, `facility_type`, `pax_number`, `checkin_date`, `checkout_date`) VALUES
(1, 1, 1, 'Main hall', 1000, '2024-08-31', '2024-09-01'),
(3, 1, 5, 'Gymnasium', 10, '2024-09-02', '2024-09-03'),
(4, 2, 2, 'Banquet Hall', 50, '2024-09-01', '2024-09-03');

-- --------------------------------------------------------

--
-- Table structure for table `facility_details`
--

CREATE TABLE `facility_details` (
  `id` int(11) NOT NULL,
  `facility_type` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `price` float NOT NULL,
  `availability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`availability`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facility_details`
--

INSERT INTO `facility_details` (`id`, `facility_type`, `capacity`, `price`, `availability`) VALUES
(1, 'Main hall', 1000, 20, '\"2024-08-31\"'),
(2, 'Banquet Hall', 200, 5, '\"2024-09-01,2024-09-02\"'),
(4, 'Library', 50, 0, '\"\"'),
(5, 'Gymnasium', 20, 5, '\"2024-09-02\"');

-- --------------------------------------------------------

--
-- Table structure for table `menu_details`
--

CREATE TABLE `menu_details` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_details`
--

INSERT INTO `menu_details` (`id`, `menu_name`, `price`) VALUES
(1, 'Nasi Goreng Cina', 8),
(2, 'Nasi Goreng Kampung', 9),
(3, 'Nasi Goreng Daging', 10),
(4, 'Maggi Goreng', 6),
(6, 'Kuetiaw Tomyam', 7);

-- --------------------------------------------------------

--
-- Table structure for table `ordermenu_details`
--

CREATE TABLE `ordermenu_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ordermenu_details`
--

INSERT INTO `ordermenu_details` (`id`, `order_id`, `menu_name`, `quantity`) VALUES
(1, 1, 'Nasi Goreng Cina', 2),
(3, 1, 'Maggi Goreng', 1),
(4, 2, 'Maggi Goreng', 1),
(5, 2, 'Kuetiaw Tomyam', 1),
(6, 3, 'Nasi Goreng Daging', 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `service_type` varchar(50) DEFAULT NULL,
  `room_number` varchar(50) DEFAULT NULL,
  `total_price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `name`, `contact`, `email`, `date_time`, `service_type`, `room_number`, `total_price`) VALUES
(1, 'Maisarah', '012348162', 'mai@gmail.com', '2024-08-31 15:30:00', 'dine_in', NULL, 22),
(2, 'Leman', '01987663', 'man@gmail.com', '2024-09-02 12:30:00', 'delivery', '202', 13),
(3, 'Nina', '01638476654', 'na@gmail.com', '2024-09-01 14:35:00', 'pick_up', NULL, 20);

-- --------------------------------------------------------

--
-- Table structure for table `roombooking_details`
--

CREATE TABLE `roombooking_details` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `total_price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roombooking_details`
--

INSERT INTO `roombooking_details` (`id`, `name`, `contact`, `email`, `total_price`) VALUES
(4, 'Kamil', '0152437384', 'mil@gmail.com', 118),
(5, 'Hannan', '0172534453', 'nan@gmail.com', 92),
(6, 'safiya', '018273644', 'piya@gmail.com', 52);

-- --------------------------------------------------------

--
-- Table structure for table `room_booking`
--

CREATE TABLE `room_booking` (
  `id` int(11) NOT NULL,
  `roombookingdetails_id` int(11) DEFAULT NULL,
  `room_id` int(11) NOT NULL,
  `room_type` varchar(100) NOT NULL,
  `pax_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_booking`
--

INSERT INTO `room_booking` (`id`, `roombookingdetails_id`, `room_id`, `room_type`, `pax_number`, `checkin_date`, `checkout_date`) VALUES
(7, 4, 1, 'Single Room', 1, '2024-09-06', '2024-09-07'),
(8, 4, 5, '6 Bedded Room', 4, '2024-09-03', '2024-09-05'),
(9, 5, 2, 'Double Room', 1, '2024-09-07', '2024-09-08'),
(10, 5, 3, 'Deluxe Room', 2, '2024-09-18', '2024-09-20'),
(11, 6, 2, 'Double Room', 1, '2024-09-18', '2024-09-20'),
(12, 6, 5, '6 Bedded Room', 1, '2024-09-07', '2024-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `room_details`
--

CREATE TABLE `room_details` (
  `id` int(11) NOT NULL,
  `room_type` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `price` float NOT NULL,
  `availability` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`availability`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_details`
--

INSERT INTO `room_details` (`id`, `room_type`, `capacity`, `price`, `availability`) VALUES
(1, 'Single Room', 1, 22, '\"2024-09-06\"'),
(2, 'Double Room', 2, 20, '\"2024-09-07,2024-09-18,2024-09-19\"'),
(3, 'Deluxe Room', 3, 18, '\"2024-09-18,2024-09-19\"'),
(4, 'Executive Room', 4, 16, '\"\"'),
(5, '6 Bedded Room', 6, 12, '\"2024-09-03,2024-09-04,2024-09-07\"');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `facilitybooking_details`
--
ALTER TABLE `facilitybooking_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facility_booking`
--
ALTER TABLE `facility_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `facilitybookingdetails_id` (`facilitybookingdetails_id`),
  ADD KEY `facility_id` (`facility_id`);

--
-- Indexes for table `facility_details`
--
ALTER TABLE `facility_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_details`
--
ALTER TABLE `menu_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordermenu_details`
--
ALTER TABLE `ordermenu_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roombooking_details`
--
ALTER TABLE `roombooking_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_booking`
--
ALTER TABLE `room_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roombookingdetails_id` (`roombookingdetails_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `room_details`
--
ALTER TABLE `room_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `facilitybooking_details`
--
ALTER TABLE `facilitybooking_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `facility_booking`
--
ALTER TABLE `facility_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `facility_details`
--
ALTER TABLE `facility_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu_details`
--
ALTER TABLE `menu_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ordermenu_details`
--
ALTER TABLE `ordermenu_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roombooking_details`
--
ALTER TABLE `roombooking_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `room_booking`
--
ALTER TABLE `room_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `room_details`
--
ALTER TABLE `room_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `facility_booking`
--
ALTER TABLE `facility_booking`
  ADD CONSTRAINT `facility_booking_ibfk_1` FOREIGN KEY (`facilitybookingdetails_id`) REFERENCES `facilitybooking_details` (`id`),
  ADD CONSTRAINT `facility_booking_ibfk_2` FOREIGN KEY (`facility_id`) REFERENCES `facility_details` (`id`);

--
-- Constraints for table `ordermenu_details`
--
ALTER TABLE `ordermenu_details`
  ADD CONSTRAINT `ordermenu_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order_details` (`id`);

--
-- Constraints for table `room_booking`
--
ALTER TABLE `room_booking`
  ADD CONSTRAINT `room_booking_ibfk_1` FOREIGN KEY (`roombookingdetails_id`) REFERENCES `roombooking_details` (`id`),
  ADD CONSTRAINT `room_booking_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `room_details` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
