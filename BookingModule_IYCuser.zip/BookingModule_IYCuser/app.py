from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, timedelta
from models import db, Order, Menu, OrderMenu, RoomBooking, RoomBookingDetails, RoomDetails, FacilityDetails, FacilityBookingDetails, FacilityBooking
import json

app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:@localhost/hostel'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route("/")
def main_page():
    return render_template('main.html')

@app.route('/cafe', methods=['GET', 'POST'])
def cafe():
    if request.method == 'POST':
        menu_name = request.form.get('menu_name')
        price = request.form.get('price')
        new_menu = Menu(
            menu_name=menu_name,
            price=price
        )
        db.session.add(new_menu)
        db.session.commit()
        return redirect(url_for('cafe'))

    cafe = Menu.query.all()
    return render_template('menu_details.html', cafe=cafe)


@app.route('/cafe/add', methods=['GET', 'POST'])
def add_cafe():
    if request.method == 'POST':
        # Adding new menu
        menu_name = request.form.get('menu_name')
        price = request.form.get('price')
        new_menu = Menu(
            menu_name=menu_name,
            price=price,
        )
        db.session.add(new_menu)
        db.session.commit()
        return redirect(url_for('cafe'))

    return render_template('add_cafe.html')

@app.route('/cafe/update/<int:id>', methods=['GET', 'POST'])
def update_cafe(id):
    cafe = Menu.query.get_or_404(id)
    if request.method == 'POST':
        cafe.menu_name = request.form.get('menu_name')
        cafe.price = request.form.get('price')
        db.session.commit()
        return redirect(url_for('cafe'))

    return render_template('update_cafe.html', cafe=cafe)

@app.route('/cafe/delete/<int:id>', methods=['POST'])
def delete_cafe(id):
    cafe = Menu.query.get_or_404(id)
    db.session.delete(cafe)
    db.session.commit()
    return redirect(url_for('cafe'))


@app.route('/view_orders')
def view_orders():
    orders = Order.query.all()
    return render_template('view_list_orders.html', orders=orders)

@app.route('/view_order_details/<int:order_id>')
def view_order_details(order_id):
    order = Order.query.get_or_404(order_id)
    order_items = OrderMenu.query.filter_by(order_id=order_id).all()
    return render_template('view_list_menuorders.html', order=order, order_items=order_items)


@app.route('/room', methods=['GET'])
def list_room():
    rooms = RoomDetails.query.all()
    return render_template('list_room.html', rooms=rooms)

@app.route('/room/add', methods=['GET', 'POST'])
def add_room():
    if request.method == 'POST':
        room_type = request.form.get('room_type')
        capacity = request.form.get('capacity')
        price = request.form.get('price')
        new_room = RoomDetails(
            room_type=room_type,
            capacity=capacity,
            price=price,
            availability=''  # Initial availability is empty
        )
        db.session.add(new_room)
        db.session.commit()
        return redirect(url_for('list_room'))

    return render_template('add_room.html')

@app.route('/room/delete/<int:id>', methods=['POST'])
def delete_room(id):
    room = RoomDetails.query.get_or_404(id)
    db.session.delete(room)
    db.session.commit()
    return redirect(url_for('list_room'))

@app.route('/room/update/<int:id>', methods=['GET', 'POST'])
def update_room(id):
    room = RoomDetails.query.get_or_404(id)
    if request.method == 'POST':
        room.room_type = request.form.get('room_type')
        room.capacity = request.form.get('capacity')
        room.price = request.form.get('price')
        db.session.commit()
        return redirect(url_for('list_room'))
    return render_template('update_room.html', room=room)


@app.route('/view_list_bookings')
def view_list_bookings():
    bookings = RoomBookingDetails.query.all()
    return render_template('view_list_bookings.html', bookings=bookings)

@app.route('/view_room_booking_details/<int:booking_id>')
def view_room_booking_details(booking_id):
    booking = RoomBookingDetails.query.get_or_404(booking_id)
    room_bookings = RoomBooking.query.filter_by(roombookingdetails_id=booking_id).all()
    return render_template('view_room_booking_details.html', booking=booking, room_bookings=room_bookings)




@app.route('/facility', methods=['GET'])
def list_facility():
    facilities = FacilityDetails.query.all()
    return render_template('listfacility.html', facilities=facilities)

@app.route('/facility/add', methods=['GET', 'POST'])
def add_facility():
    if request.method == 'POST':
        facility_type = request.form.get('facility_type')
        capacity = request.form.get('capacity')
        price = request.form.get('price')
        new_facility = FacilityDetails(
            facility_type=facility_type,
            capacity=capacity,
            price=price,
            availability=''  # Initial availability is empty
        )
        db.session.add(new_facility)
        db.session.commit()
        return redirect(url_for('list_facility'))

    return render_template('addfacility.html')

@app.route('/facility/delete/<int:id>', methods=['POST'])
def delete_facility(id):
    facility = FacilityDetails.query.get_or_404(id)
    db.session.delete(facility)
    db.session.commit()
    return redirect(url_for('list_facility'))

@app.route('/facility/update/<int:id>', methods=['GET', 'POST'])
def update_facility(id):
    facility = FacilityDetails.query.get_or_404(id)
    if request.method == 'POST':
        facility.facility_type = request.form.get('facility_type')
        facility.capacity = request.form.get('capacity')
        facility.price = request.form.get('price')
        db.session.commit()
        return redirect(url_for('list_facility'))
    return render_template('updatefacility.html', facility=facility)


@app.route('/view_facility_bookings')
def view_facility_bookings():
    bookings = FacilityBookingDetails.query.all()
    return render_template('viewfacilitybookings.html', bookings=bookings)

@app.route('/view_facility_booking_details/<int:booking_id>')
def view_facility_booking_details(booking_id):
    booking = FacilityBookingDetails.query.get_or_404(booking_id)
    facility_bookings = FacilityBooking.query.filter_by(facilitybookingdetails_id=booking_id).all()
    return render_template('viewfacilitybookings.html', booking=booking, facility_bookings=facility_bookings)




if __name__ == "__main__":
    app.run(debug=True)
