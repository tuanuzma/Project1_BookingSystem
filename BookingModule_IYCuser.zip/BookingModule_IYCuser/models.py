from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Float, Date, DateTime

db = SQLAlchemy()

class Order(db.Model):
    __tablename__ = "order_details"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    contact = db.Column(db.String(50))
    email = db.Column(db.String(100))
    date_time = db.Column(db.DateTime)
    service_type = db.Column(db.String(50))
    room_number = db.Column(db.String(50), nullable=True)
    total_price = db.Column(db.Float)
    details = db.relationship('OrderMenu', backref='order', lazy=True)

class Menu(db.Model):
    __tablename__ = "menu_details"
    id = db.Column(db.Integer, primary_key=True)
    menu_name = db.Column(db.String(100))
    price = db.Column(db.Float)

class OrderMenu(db.Model):
    __tablename__ = "ordermenu_details"
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order_details.id'), nullable=False)
    menu_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

class RoomDetails(db.Model):
    __tablename__ = "room_details"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    room_type = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    availability = db.Column(db.JSON, nullable=True, default=None)  
    
    # Relationship with RoomBooking, including cascade delete
    room_bookings = db.relationship('RoomBooking', backref='room', cascade='all, delete-orphan')

class RoomBookingDetails(db.Model):
    __tablename__ = "roombooking_details"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100))
    contact = db.Column(db.String(50))
    email = db.Column(db.String(100))
    total_price = db.Column(db.Float, nullable=False)
    details = db.relationship('RoomBooking', backref='booking_details', lazy=True)


class RoomBooking(db.Model):
    __tablename__ = 'room_booking'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    roombookingdetails_id = db.Column(db.Integer, db.ForeignKey('roombooking_details.id'), nullable=True)
    room_id = db.Column(db.Integer, db.ForeignKey('room_details.id'), nullable=False)
    room_type = db.Column(db.String(100), nullable=False)
    pax_number = db.Column(db.Integer, nullable=False)
    checkin_date = db.Column(db.Date, nullable=False)
    checkout_date = db.Column(db.Date, nullable=False)

    # Optional: You can use backref here for easier access to RoomDetails from RoomBooking
    # room = db.relationship('RoomDetails', backref=backref('bookings', cascade='all, delete-orphan'))


 
class FacilityDetails(db.Model):
    __tablename__ = "facility_details"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    facility_type = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    availability = db.Column(db.JSON, nullable=True, default=None)  
    
    # Relationship with FacilityBooking, including cascade delete
    facility_bookings = db.relationship('FacilityBooking', backref='facility', cascade='all, delete-orphan')

class FacilityBookingDetails(db.Model):
    __tablename__ = "facilitybooking_details"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100))
    contact = db.Column(db.String(50))
    email = db.Column(db.String(100))
    total_price = db.Column(db.Float, nullable=False)
    details = db.relationship('FacilityBooking', backref='booking_details', lazy=True)


class FacilityBooking(db.Model):
    __tablename__ = 'facility_booking'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    facilitybookingdetails_id = db.Column(db.Integer, db.ForeignKey('facilitybooking_details.id'), nullable=True)
    facility_id = db.Column(db.Integer, db.ForeignKey('facility_details.id'), nullable=False)
    facility_type = db.Column(db.String(100), nullable=False)
    pax_number = db.Column(db.Integer, nullable=False)
    checkin_date = db.Column(db.Date, nullable=False)
    checkout_date = db.Column(db.Date, nullable=False)

    # Optional: You can use backref here for easier access to FacilityDetails from FacilityBooking
    # facility = db.relationship('FacilityDetails', backref=backref('bookings', cascade='all, delete-orphan'))


 