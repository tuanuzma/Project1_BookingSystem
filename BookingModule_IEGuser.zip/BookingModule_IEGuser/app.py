from flask import Flask, render_template, request, redirect, url_for, session, flash # type: ignore
from datetime import datetime, timedelta
from models import db, Order, Menu, OrderMenu, RoomBooking, RoomBookingDetails, RoomDetails, FacilityDetails, FacilityBookingDetails, FacilityBooking
import json

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:@localhost/hostel'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route("/")
def main_page():
    return render_template('main.html')


@app.route('/view_menu', methods=['GET', 'POST'])
def view_menu():
    if request.method == 'POST':
        selected_items = {}
        for key, value in request.form.items():
            if key.startswith('menu_'):
                item_id = key.split('_')[1]
                quantity = int(value) if value else 0
                if quantity:
                    selected_items[item_id] = quantity

        session['selected_items'] = selected_items
        return redirect(url_for('confirmation'))

    menu_items = Menu.query.all()
    return render_template('view_menu.html', menu_items=menu_items)

@app.route('/confirmation', methods=['GET', 'POST'])
def confirmation():
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        email = request.form['email']
        date_time_str = request.form['date_time']
        service_type = request.form['service_type']
        room_number = request.form.get('room_number', '')

        try:
            date_time = datetime.strptime(date_time_str, '%Y-%m-%dT%H:%M')
        except ValueError:
            return "Invalid date/time format. Please use YYYY-MM-DDTHH:MM.", 400

        selected_items = session.get('selected_items', {})
        if not isinstance(selected_items, dict):
            return "Error: selected_items should be a dictionary.", 400

        total_price = calculate_order_total_price(selected_items)

        order_id = save_order(name, contact, email, date_time, service_type, room_number, total_price)

        session.pop('selected_items', None)

        return redirect(url_for('order_confirmation'))

    selected_items = session.get('selected_items', {})
    if not isinstance(selected_items, dict):
        return "Error: selected_items should be a dictionary.", 400

    menu_items = []
    for item_id, quantity in selected_items.items():
        menu_item = Menu.query.get(item_id)  
        if menu_item:
            menu_items.append((menu_item.menu_name, quantity))  

    return render_template('confirmation.html', menu_items=menu_items)

@app.route('/view_orders')
def view_orders():
    orders = Order.query.all()
    return render_template('view_list_orders.html', orders=orders)

@app.route('/view_order_details/<int:order_id>')
def view_order_details(order_id):
    order = Order.query.get_or_404(order_id)
    order_items = OrderMenu.query.filter_by(order_id=order_id).all()

    order.total_price = calculate_order_total_price_by_order_id(order_id)
    db.session.commit()

    return render_template('view_list_menuorders.html', order=order, order_items=order_items)

@app.route('/add_order/<int:order_id>', methods=['GET', 'POST'])
def add_order(order_id):
    if request.method == 'POST':
        menu_id = request.form.get('menu_id')
        quantity = request.form.get('quantity')

        try:
            quantity = int(quantity)
        except ValueError:
            flash('Invalid quantity.', 'error')
            return redirect(url_for('add_order', order_id=order_id))

        menu_item = Menu.query.get_or_404(menu_id)

        new_order_item = OrderMenu(
            order_id=order_id,
            menu_name=menu_item.menu_name,
            quantity=quantity
        )
        db.session.add(new_order_item)
        db.session.commit()

        order = Order.query.get_or_404(order_id)
        order.total_price = calculate_order_total_price_by_order_id(order_id)
        db.session.commit()

        return redirect(url_for('view_order_details', order_id=order_id))

    menu_items = Menu.query.all()
    return render_template('add_order.html', order_id=order_id, menu_items=menu_items)

@app.route('/order_confirmation')
def order_confirmation():
    return redirect(url_for('main_page'))

@app.route('/edit_menu_order/<int:order_id>/<int:item_id>', methods=['GET', 'POST'])
def edit_menu_order(order_id, item_id):
    order_item = OrderMenu.query.get_or_404(item_id)
    
    if request.method == 'POST':
        new_quantity = int(request.form['quantity'])
        order_item.quantity = new_quantity
        db.session.commit()

        order = Order.query.get_or_404(order_id)
        order.total_price = calculate_order_total_price_by_order_id(order_id)
        db.session.commit()

        return redirect(url_for('view_order_details', order_id=order_id))

    return render_template('edit_menu_order.html', order_item=order_item)

@app.route('/delete_menu_order/<int:order_id>/<int:item_id>')
def delete_menu_order(order_id, item_id):
    order_item = OrderMenu.query.get_or_404(item_id)
    
    db.session.delete(order_item)
    db.session.commit()

    order_items = OrderMenu.query.filter_by(order_id=order_id).all()
    
    if not order_items:
        order = Order.query.get_or_404(order_id)
        db.session.delete(order)
        db.session.commit()
        flash('Order and all its items have been deleted.', 'info')
        return redirect(url_for('view_orders'))  

    order = Order.query.get_or_404(order_id)
    order.total_price = calculate_order_total_price_by_order_id(order_id)
    db.session.commit()

    flash('Order item deleted.', 'info')
    return redirect(url_for('view_order_details', order_id=order_id)) 


def calculate_order_total_price(selected_items):
    total_price = 0
    for menu_id, quantity in selected_items.items():
        menu_item = Menu.query.get(menu_id)
        if menu_item:
            total_price += menu_item.price * quantity
    return total_price

def calculate_order_total_price_by_order_id(order_id):
    total_price = 0
    order_items = OrderMenu.query.filter_by(order_id=order_id).all()
    for item in order_items:
        menu_item = Menu.query.filter_by(menu_name=item.menu_name).first()
        if menu_item:
            total_price += menu_item.price * item.quantity
    return total_price

def save_order(name, contact, email, date_time, service_type, room_number, total_price):
    order = Order(
        name=name,
        contact=contact,
        email=email,
        service_type=service_type,
        room_number=room_number if service_type == 'delivery' else None,
        date_time=date_time,
        total_price=total_price
    )
    db.session.add(order)
    db.session.commit()

    selected_items = session.get('selected_items', {})
    for menu_id, quantity in selected_items.items():
        menu_item = Menu.query.get(menu_id)
        if menu_item:
            order_detail = OrderMenu(
                order_id=order.id,
                menu_name=menu_item.menu_name,
                quantity=quantity
            )
            db.session.add(order_detail)

    db.session.commit()
    return order.id

@app.route('/payment_page/<int:order_id>', methods=['GET', 'POST'])
def payment_page_order(order_id):
    order = Order.query.get_or_404(order_id)
    
    if request.method == 'POST':
        flash('Payment processing is not implemented yet.', 'info')
        return redirect(url_for('payment_page_order', order_id=order_id))

    return render_template('payment.html', order=order)





@app.route('/view_room_list', methods=['GET', 'POST'])
def view_room_list():
    if request.method == 'POST':
        selected_rooms = []
        for key, value in request.form.items():
            if key.startswith('room_'):
                room_id = key.split('_')[1]
                checkin_date = request.form.get(f'checkin_date_{room_id}')
                checkout_date = request.form.get(f'checkout_date_{room_id}')
                pax_number = request.form.get(f'pax_number_{room_id}')

                if checkin_date and checkout_date and pax_number:
                    selected_rooms.append({
                        'room_id': int(room_id),  
                        'checkin_date': checkin_date,
                        'checkout_date': checkout_date,
                        'pax_number': pax_number
                    })

        session['selected_rooms'] = selected_rooms
        return redirect(url_for('confirm_room_booking'))

    room_list = RoomDetails.query.all()
    unavailable_dates = {}
    
    for room in room_list:
        room_id = room.id
        bookings = RoomBooking.query.filter_by(room_type=room.room_type).all()
        dates = set()
        for booking in bookings:
            start_date = booking.checkin_date
            end_date = booking.checkout_date
            current_date = start_date
            while current_date < end_date:
                dates.add(current_date.strftime('%Y-%m-%d'))
                current_date += timedelta(days=1)
        unavailable_dates[room_id] = list(dates)

    return render_template('view_room_list.html', room_list=room_list, unavailable_dates=unavailable_dates)


@app.route('/confirm_room_booking', methods=['GET', 'POST'])
def confirm_room_booking():
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        email = request.form['email']

        total_price = 0
        selected_rooms = session.get('selected_rooms', [])

        for room in selected_rooms:
            room_detail = RoomDetails.query.get(room['room_id'])
            nights = (datetime.strptime(room['checkout_date'], '%Y-%m-%d') - 
                      datetime.strptime(room['checkin_date'], '%Y-%m-%d')).days
            total_price += room_detail.price * int(room['pax_number']) * nights

        booking_id = save_room_booking(name, contact, email, total_price)

        for room in selected_rooms:
            save_individual_booking(booking_id, room['room_id'], room['checkin_date'], 
                                    room['checkout_date'], room['pax_number'])

        session.pop('selected_rooms', None)
        return redirect(url_for('view_list_bookings'))

    selected_rooms = session.get('selected_rooms', [])
    room_details = [(RoomDetails.query.get(room['room_id']), room) for room in selected_rooms]

    return render_template('confirm_room_booking.html', room_details=room_details)


def save_room_booking(name, contact, email, total_price):
    booking = RoomBookingDetails(
        name=name,
        contact=contact,
        email=email,
        total_price=total_price
    )
    db.session.add(booking)
    db.session.commit()
    return booking.id


def save_individual_booking(booking_id, room_id, checkin_date, checkout_date, pax_number):
    room = RoomDetails.query.get(room_id)
    if not room:
        print(f"Room with ID {room_id} not found.")
        return

    booking = RoomBooking(
        roombookingdetails_id=booking_id,
        room_id=room_id,
        room_type=room.room_type,
        pax_number=pax_number,
        checkin_date=checkin_date,
        checkout_date=checkout_date
    )
    db.session.add(booking)
    db.session.commit()

    update_availability(room, checkin_date, checkout_date)


@app.route('/view_list_bookings')
def view_list_bookings():
    bookings = RoomBookingDetails.query.all()
    return render_template('view_list_bookings.html', bookings=bookings)


@app.route('/edit_room_booking/<int:booking_id>/<int:room_booking_id>', methods=['GET', 'POST'])
def edit_room_booking(booking_id, room_booking_id):
    room_booking = RoomBooking.query.get_or_404(room_booking_id)

    if request.method == 'POST':
        old_checkin = room_booking.checkin_date
        old_checkout = room_booking.checkout_date

        room_booking.checkin_date = request.form['checkin_date']
        room_booking.checkout_date = request.form['checkout_date']
        room_booking.pax_number = request.form['pax_number']
        db.session.commit()

        room_details = RoomDetails.query.filter_by(room_type=room_booking.room_type).first()

        remove_booking_availability(room_booking.room_type, old_checkin, old_checkout)
        update_availability(room_details, room_booking.checkin_date, room_booking.checkout_date)

        update_total_price(booking_id)

        return redirect(url_for('view_room_booking_details', booking_id=booking_id))

    return render_template('edit_room_booking.html', room_booking=room_booking)


def update_total_price(booking_id):
    room_bookings = RoomBooking.query.filter_by(roombookingdetails_id=booking_id).all()
    total_price = 0

    for room_booking in room_bookings:
        room_details = RoomDetails.query.filter_by(room_type=room_booking.room_type).first()
        nights = (room_booking.checkout_date - room_booking.checkin_date).days
        total_price += room_details.price * int(room_booking.pax_number) * nights

    booking_details = RoomBookingDetails.query.get(booking_id)
    booking_details.total_price = total_price
    db.session.commit()


def remove_booking_availability(room_type, checkin_date, checkout_date):
    room = RoomDetails.query.filter_by(room_type=room_type).first()
    if room:
        if isinstance(checkin_date, str):
            checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        if isinstance(checkout_date, str):
            checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()
        
        booked_dates = [(checkin_date + timedelta(days=i)).strftime('%Y-%m-%d')
                        for i in range((checkout_date - checkin_date).days)]
        availability_dates = room.availability.split(',') if room.availability else []
        updated_dates = sorted(set(availability_dates) - set(booked_dates))
        room.availability = ','.join(updated_dates)
        db.session.commit()

def update_availability(room, checkin_date, checkout_date):
    room_details = RoomDetails.query.filter_by(room_type=room.room_type).first()
    if room_details:
        # Ensure checkin_date and checkout_date are datetime.date objects
        if isinstance(checkin_date, str):
            checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        if isinstance(checkout_date, str):
            checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

        new_dates = [(checkin_date + timedelta(days=i)).strftime('%Y-%m-%d')
                     for i in range((checkout_date - checkin_date).days)]
        availability_dates = room_details.availability.split(',') if room_details.availability else []
        updated_dates = sorted(set(availability_dates + new_dates))
        room_details.availability = ','.join(updated_dates)
        db.session.commit()

@app.route('/view_room_booking_details/<int:booking_id>')
def view_room_booking_details(booking_id):
    booking = RoomBookingDetails.query.get_or_404(booking_id)
    room_bookings = RoomBooking.query.filter_by(roombookingdetails_id=booking_id).all()
    return render_template('view_room_booking_details.html', booking=booking, room_bookings=room_bookings)

@app.route('/delete_room_booking/<int:booking_id>/<int:room_booking_id>')
def delete_room_booking(booking_id, room_booking_id):
    room_booking = RoomBooking.query.get_or_404(room_booking_id)
    db.session.delete(room_booking)
    db.session.commit()

    remove_booking_availability(room_booking.room_type, room_booking.checkin_date, room_booking.checkout_date)
    
    return redirect(url_for('view_room_booking_details', booking_id=booking_id))


@app.route('/add_room_booking/<int:booking_id>', methods=['GET', 'POST'])
def add_room_booking(booking_id):
    if request.method == 'POST':
        selected_rooms = request.form.getlist('room_id')
        
        if not selected_rooms:
            flash("Please select at least one room to book.", "danger")
            return redirect(url_for('add_room_booking', booking_id=booking_id))

        for room_id in selected_rooms:
            checkin_date = request.form.get(f'checkin_date_{room_id}')
            checkout_date = request.form.get(f'checkout_date_{room_id}')
            pax_number = request.form.get(f'pax_number_{room_id}')

            if not (checkin_date and checkout_date and pax_number):
                flash(f"Please fill in all the required details for the selected room {room_id}.", "danger")
                return redirect(url_for('add_room_booking', booking_id=booking_id))

            room_detail = RoomDetails.query.get(room_id)

            if room_detail:
                save_individual_booking(booking_id, room_id, checkin_date, checkout_date, pax_number)

            else:
                flash(f"Selected room with ID {room_id} is not available.", "danger")
                return redirect(url_for('add_room_booking', booking_id=booking_id))
            
        
        update_total_price(booking_id)
        return redirect(url_for('view_room_booking_details', booking_id=booking_id))

    available_rooms = RoomDetails.query.all()

    unavailable_dates = {}
    for room in available_rooms:
        dates = room.availability.split(',') if room.availability else []
        unavailable_dates[room.id] = dates

    return render_template('add_room_booking.html', available_rooms=available_rooms, booking_id=booking_id, unavailable_dates=unavailable_dates)




@app.route('/view_facility_list', methods=['GET', 'POST'])
def view_facility_list():
    if request.method == 'POST':
        selected_facilities = []
        for key, value in request.form.items():
            if key.startswith('facility_'):
                facility_id = key.split('_')[1]
                checkin_date = request.form.get(f'checkin_date_{facility_id}')
                checkout_date = request.form.get(f'checkout_date_{facility_id}')
                pax_number = request.form.get(f'pax_number_{facility_id}')

                if checkin_date and checkout_date and pax_number:
                    selected_facilities.append({
                        'facility_id': int(facility_id),  
                        'checkin_date': checkin_date,
                        'checkout_date': checkout_date,
                        'pax_number': pax_number
                    })

        session['selected_facilities'] = selected_facilities
        return redirect(url_for('confirm_facility_booking'))


    facility_list = FacilityDetails.query.all()
    unavailable_dates = {}
    
    for facility in facility_list: #
        facility_id = facility.id
        bookings = FacilityBooking.query.filter_by(facility_type=facility.facility_type).all()
        dates = set()
        for booking in bookings:
            start_date = booking.checkin_date
            end_date = booking.checkout_date
            current_date = start_date
            while current_date < end_date:
                dates.add(current_date.strftime('%Y-%m-%d'))
                current_date += timedelta(days=1)
        unavailable_dates[facility_id] = list(dates)

    return render_template('viewfacilitylist.html', facility_list=facility_list, unavailable_dates=unavailable_dates)


@app.route('/confirm_facility_booking', methods=['GET', 'POST'])
def confirm_facility_booking():
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        email = request.form['email']

        total_price = 0
        selected_facilities = session.get('selected_facilities', [])

        for facility in selected_facilities:
            facility_detail = FacilityDetails.query.get(facility['facility_id'])
            nights = (datetime.strptime(facility['checkout_date'], '%Y-%m-%d') - 
                      datetime.strptime(facility['checkin_date'], '%Y-%m-%d')).days
            total_price += facility_detail.price * int(facility['pax_number']) * nights


        booking_id = save_facility_booking(name, contact, email, total_price)

        for facility in selected_facilities:
              save_individualfaci_booking(booking_id, facility['facility_id'], facility['checkin_date'], 
                                    facility['checkout_date'], facility['pax_number'])

        session.pop('selected_facilities', None)
        return redirect(url_for('view_listfac_bookings'))

    selected_facilities = session.get('selected_facilities', [])
    facility_details = [(FacilityDetails.query.get(facility['facility_id']), facility) for facility in selected_facilities]

    return render_template('confirmfacility_booking.html', facility_details=facility_details)


def save_facility_booking(name, contact, email, total_price):
    booking = FacilityBookingDetails(
        name=name,
        contact=contact,
        email=email,
        total_price=total_price
    )
    db.session.add(booking)
    db.session.commit()
    return booking.id


def save_individualfaci_booking(booking_id, facility_id, checkin_date, checkout_date, pax_number):
    facility = FacilityDetails.query.get(facility_id)
    if not facility:
        print(f"Facility with ID {facility_id} not found.")
        return

    booking = FacilityBooking(
        facilitybookingdetails_id=booking_id,
        facility_id=facility_id,
        facility_type=facility.facility_type,
        pax_number=pax_number,
        checkin_date=checkin_date,
        checkout_date=checkout_date
    )
    db.session.add(booking)
    db.session.commit()

    updatefaci_availability(facility, checkin_date, checkout_date)


@app.route('/view_listfac_bookings')
def view_listfac_bookings():
    bookings = FacilityBookingDetails.query.all()
    return render_template('viewlistfac_bookings.html', bookings=bookings)


@app.route('/edit_facility_booking/<int:booking_id>/<int:facility_booking_id>', methods=['GET', 'POST'])
def edit_facility_booking(booking_id, facility_booking_id):
    facility_booking = FacilityBooking.query.get_or_404(facility_booking_id)

    if request.method == 'POST':
        old_checkin = facility_booking.checkin_date
        old_checkout = facility_booking.checkout_date

        facility_booking.checkin_date = request.form['checkin_date']
        facility_booking.checkout_date = request.form['checkout_date']
        facility_booking.pax_number = request.form['pax_number']
        db.session.commit()

        facility_details = FacilityDetails.query.filter_by(facility_type=facility_booking.facility_type).first()


        removefaci_booking_availability(facility_booking.facility_type, old_checkin, old_checkout)
        updatefaci_availability(facility_details, facility_booking.checkin_date, facility_booking.checkout_date)

        updatefaci_total_price(booking_id)

        return redirect(url_for('view_facility_bookings_details', booking_id=booking_id))

    return render_template('editfacility_booking.html', facility_booking=facility_booking)


def updatefaci_total_price(booking_id):
    facility_bookings = FacilityBooking.query.filter_by(facilitybookingdetails_id=booking_id).all()
    total_price = 0

    for facility_booking in facility_bookings:
        facility_details = FacilityDetails.query.filter_by(facility_type=facility_booking.facility_type).first()
        nights = (facility_booking.checkout_date - facility_booking.checkin_date).days
        total_price += facility_details.price * int(facility_booking.pax_number) * nights

    booking_details = FacilityBookingDetails.query.get(booking_id)
    booking_details.total_price = total_price
    db.session.commit()


def removefaci_booking_availability(facility_type, checkin_date, checkout_date):
    facility = FacilityDetails.query.filter_by(facility_type=facility_type).first()
    if facility:
        if isinstance(checkin_date, str):
            checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        if isinstance(checkout_date, str):
            checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

        
        booked_dates = [(checkin_date + timedelta(days=i)).strftime('%Y-%m-%d')
                        for i in range((checkout_date - checkin_date).days)]
        availability_dates = facility.availability.split(',') if facility.availability else []
        updated_dates = sorted(set(availability_dates) - set(booked_dates))
        facility.availability = ','.join(updated_dates)
        db.session.commit()

def updatefaci_availability(facility, checkin_date, checkout_date):
    facility_details = FacilityDetails.query.filter_by(facility_type=facility.facility_type).first()
    if facility_details:
        # Ensure checkin_date and checkout_date are datetime.date objects
        if isinstance(checkin_date, str):
            checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        if isinstance(checkout_date, str):
            checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

        new_dates = [(checkin_date + timedelta(days=i)).strftime('%Y-%m-%d')
                     for i in range((checkout_date - checkin_date).days)]
        availability_dates = facility_details.availability.split(',') if facility_details.availability else []
        updated_dates = sorted(set(availability_dates + new_dates))
        facility_details.availability = ','.join(updated_dates)
        db.session.commit()

@app.route('/view_facility_bookings_details/<int:booking_id>')
def view_facility_bookings_details(booking_id):
    booking = FacilityBookingDetails.query.get_or_404(booking_id)
    facility_bookings = FacilityBooking.query.filter_by(facilitybookingdetails_id=booking_id).all()
    return render_template('viewfacility_bookings_details.html', booking=booking, facility_bookings=facility_bookings)

@app.route('/delete_facility_booking/<int:booking_id>/<int:facility_booking_id>')
def delete_facility_booking(booking_id, facility_booking_id):
    facility_booking = FacilityBooking.query.get_or_404(facility_booking_id)
    db.session.delete(facility_booking)
    db.session.commit()

    removefaci_booking_availability(facility_booking.facility_type, facility_booking.checkin_date, facility_booking.checkout_date)
    
    return redirect(url_for('view_facility_bookings_details', booking_id=booking_id))


@app.route('/add_facility_booking/<int:booking_id>', methods=['GET', 'POST'])
def add_facility_booking(booking_id):
    if request.method == 'POST':
        selected_facilities = request.form.getlist('facility_id')
        
        if not selected_facilities:
            flash("Please select at least one facility to book.", "danger")
            return redirect(url_for('add_facility_booking', booking_id=booking_id))

        for facility_id in selected_facilities:
            checkin_date = request.form.get(f'checkin_date_{facility_id}')
            checkout_date = request.form.get(f'checkout_date_{facility_id}')
            pax_number = request.form.get(f'pax_number_{facility_id}')

            if not (checkin_date and checkout_date and pax_number):
                flash(f"Please fill in all the required details for the selected facility {facility_id}.", "danger")
                return redirect(url_for('add_facility_booking', booking_id=booking_id))

            facility_detail = FacilityDetails.query.get(facility_id)

            if facility_detail:
                save_individualfaci_booking(booking_id, facility_id, checkin_date, checkout_date, pax_number)

            else:
                flash(f"Selected facility with ID {facility_id} is not available.", "danger")
                return redirect(url_for('add_facility_booking', booking_id=booking_id))
            
        
        updatefaci_total_price(booking_id)
        return redirect(url_for('view_facility_bookings_details', booking_id=booking_id))

    available_facilities = FacilityDetails.query.all()

    unavailable_dates = {}
    for facility in available_facilities:
        dates = facility.availability.split(',') if facility.availability else []
        unavailable_dates[facility.id] = dates

    return render_template('addfacility_booking.html', available_facilities=available_facilities, booking_id=booking_id, unavailable_dates=unavailable_dates)


if __name__ == "__main__":
    app.run(debug=True)
